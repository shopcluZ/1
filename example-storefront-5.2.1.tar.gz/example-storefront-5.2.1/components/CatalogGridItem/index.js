export { default } from "./CatalogGridItem";
