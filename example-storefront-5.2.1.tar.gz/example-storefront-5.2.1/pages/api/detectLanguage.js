import localeMiddleware from "apiUtils/localeMiddleware";

export default (req, res) => localeMiddleware(req, res);
