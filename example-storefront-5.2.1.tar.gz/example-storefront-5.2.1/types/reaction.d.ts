declare module "@reactioncommerce/components/ShopLogo/v1";
