/**
 * Configure or replace analytics tracking here.
 * See https://github.com/reactioncommerce/reaction-next-starterkit/blob/master/docs/tracking-events.md
 */

import * as segment from "./segment";

export default [
  segment
];
