export default {
  de: "Deutsch",
  en: "English",
  updatedAtDesc: "Neueste",
  minPriceAsc: "Preis: aufsteigend",
  minPriceDesc: "Preis: absteigend",
  products: "Produkte"
};
