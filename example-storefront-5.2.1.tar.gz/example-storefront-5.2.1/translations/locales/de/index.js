import common from "./common";
import productDetail from "./productDetail";

export default {
  common,
  productDetail
};
