export default {
  de: "Deutsch",
  en: "English",
  updatedAtDesc: "Newest",
  minPriceAsc: "Price: low to high",
  minPriceDesc: "Price: high to low",
  products: "Products"
};
