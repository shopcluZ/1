export const defaultLocale = "en";
export const locales = ["en", "de"];
